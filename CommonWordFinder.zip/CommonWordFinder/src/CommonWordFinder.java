import java.io.*;
import java.util.Arrays;
import java.util.Iterator;

/**
 * This class finds the n most common words in a document
 * implementing the MyMap interface.
 * @author Joshua Agubata
 */
public class CommonWordFinder{

    /**
     * @param array The array that is passed in unsorted and leaves sorted.
     */

    private static void mergesort(Entry[] array) {
        Entry[] scratch = new Entry[array.length];
        mergesortHelper(array, scratch, 0, array.length - 1);
    }

    /**
     * @param array The array that is passed in unsorted and leaves sorted.
     * @param scratch The array that the two smaller subarrays are being merged into and
     *                ultimately the array that will copy all of its contents at the end
     *                into "array".
     * @param low The lower bound of any given subarray.
     * @param high The upper bound of any given subarray.
     */
    private static void mergesortHelper (Entry[] array, Entry[] scratch, int low, int high) {
        if (low < high) {
            int mid = low + (high - low) / 2;
            mergesortHelper(array, scratch, low, mid);
            mergesortHelper(array, scratch, mid + 1, high);

            int i = low, j = mid + 1;
            for (int k = low; k <= high; k++) {
                /* since .compareTo() cannot be used, I had to get the value of the array at the specific
                * indexes, cast them as an int, and set then to the variables leftSide and rightSide.
                * I also initially set rightSide to the smallest integer value because in the case that j
                * is equal to or greater than the array's length, then the left subarray will always be added. */
                int leftSide = (int) array[i].value;
                int rightSide = Integer.MIN_VALUE;
                if(j < array.length){
                    rightSide = (int) array[j].value;
                }

                /* if the left subarray item is larger than the right one, add the left one and continue. */
                if (i <= mid && (j > high || leftSide > rightSide)){
                    scratch[k] = array[i++];
                }

                /* if the left subarray item is equal to the right one, then get the string values and compare
                using isLeftBigger() method. that will return a boolean that will determine if the left subarray
                 item or the right subarray item should be added. */
                else if (i <= mid && (j > high || leftSide == rightSide)){
                    String leftString = (String) array[i].key; // saves key as string
                    String rightString = (String) array[j].key; // saves key as string
                    boolean isLeftBigger = isLeftBigger(leftString, rightString); // returns true if left is bigger, false if not
                    if(isLeftBigger){
                        scratch[k] = array[i++]; // since left is bigger, add left.
                    }
                    else{
                        scratch[k] = array[j++]; // since left is not bigger, add right
                    }
                }

                /* if the left subarray item is smaller than the right one, add the right one and continue. */
                else{
                    scratch[k] = array[j++];
                }
            }

            for (int k = low; k <= high; k++) {
                array[k] = scratch[k];
            }
        }
    }

    /**
     * @param left The first word being compared that has the same value.
     * @param right The second word being compared that has the same value.
     * @return Boolean that returns whether or not the left string is bigger than the right string.
     */
    private static boolean isLeftBigger(String left, String right){

        char leftArray[] = left.toCharArray(); // turns string into array
        char rightArray[] = right.toCharArray(); // turns string into array
        boolean leftisBigger = true; // only changes if right is bigger

        /* sets limit to the smaller of the two arrays, this time the left one */
        if(leftArray.length <= rightArray.length){
            for(int i = 0; i < leftArray.length; i++){
                // if both letters aren't the same it checks which one is larger
                if(leftArray[i] != rightArray[i]){
                    // if the left item is lower alphabetically, then right is higher alphabetically
                    if(leftArray[i] > rightArray[i]){
                        leftisBigger = false;
                    }
                    break;
                }
            }
        }

        /* sets limit to the smaller of the two arrays, this time the right one */
        else{
            leftisBigger = false;
            for(int i = 0; i < rightArray.length; i++){
                // if both letters aren't the same it checks which one is larger
                if(leftArray[i] != rightArray[i]){
                    // if the left item is lower alphabetically, then right is higher alphabetically
                    if(leftArray[i] < rightArray[i]){
                        leftisBigger = true;
                    }
                    break;
                }
            }
        }

        return leftisBigger;
    }

    /**
     * @param args The information passed into the program like the input file, data structure, and limit.
     */
    public static void main(String[] args){

        /* if command line argument is less than or equal to 1 */
        if((args.length <= 1) || (args.length > 3)){
            System.err.println("Usage: java CommonWordFinder <filename> <bst|avl|hash> [limit]");
            System.exit(1);
        }

        /* verify if input file exists. */
        try{
            BufferedReader fileExistTest = new BufferedReader(new FileReader(args[0])); // checking to see if file is valid
            fileExistTest.close(); // close so it is not wasting memory or space
        }
        catch(FileNotFoundException a){
            System.err.println("Error: Cannot open file '" + args[0] + "' for input.");
            System.exit(1);
        }
        catch(IOException b){
            System.err.println("Error: An I/O error occurred reading '" + args[0] + "'.");
            System.exit(1);
        }

        /* if second command line argument is not "bst", "avl", or "hash" exactly, it will
        * terminate the code */
        if(!((args[1].equals("bst")) || (args[1].equals("avl")) || (args[1].equals("hash")))){
            System.err.println("Error: Invalid data structure '" + args[1] + "' received.");
            System.exit(1);
        }

        /* determines if there is a third command line. if the length is 2, that means the command line
        doesn't exist and the limit will automatically be set to 10. if the length is 3, that means the
        command line does exist and the limit will be set to what the user inputted for the third command
        line argument. */
        int limit = Integer.MIN_VALUE; // set it to a value so that it is initialized

        if(args.length == 2){
            limit = 10; // default limit
        }

        if(args.length == 3){
            try{
                limit = Integer.parseInt(args[2]); // making args[2] into integer
                // if the limit is anything but 1 or greater (positive numbers) it throws an error
                if(limit <= 0){
                    System.err.println("Error: Invalid limit '" + args[2] + "' received.");
                    System.exit(1);
                }
            }
            /* in case if args[2] is not a number */
            catch(NumberFormatException a){
                System.err.println("Error: Invalid limit '" + args[2] + "' received.");
                System.exit(1);
            }
        }

        /* bst method */
        if(args[1].equals("bst")){
            MyMap<String, Integer> BSTMap = new BSTMap<>();

            /* the try block reads every item in the text file character by character, turns then
            into words, and adds them to the binary search tree */
            try{
                BufferedReader inputText = new BufferedReader(new FileReader(args[0]));
                int currentInteger; // is the currentCharacter but in integer form to work with BufferedReader
                StringBuilder currentWord = new StringBuilder(); // will contain the words being scanned

                /* current integer will continue as long as there is something in the file being scanned */
                while((currentInteger = inputText.read()) != -1){
                    char currentCharacter = (char) currentInteger; // cast currentInteger as a character

                    /* only goes into statement if there is something to scan next and the character is a letter, dash
                    in the middle of a word, or hyphen */
                    if((!(Character.isWhitespace(currentCharacter))) && ((Character.isLetter(currentCharacter)) ||
                            ((currentCharacter == '-') && (currentWord.length() != 0)) || (currentCharacter == '\''))){
                        currentCharacter = Character.toLowerCase(currentCharacter); // lowercases current character
                        currentWord.append(currentCharacter); // adds character to stringbuilder
                    }

                    /* goes into else statement if character is not a letter, dash in middle or end of word, an
                    apostrophe, or is at end of file */
                    else{
                        /* appends last character to end of word if it is valid */
                        if((!(Character.isWhitespace(currentCharacter))) && ((Character.isLetter(currentCharacter)) ||
                                ((currentCharacter == '-') && (currentWord.length() != 0)) || (currentCharacter == '\''))){
                            currentCharacter = Character.toLowerCase(currentCharacter); // lowercases current character
                            currentWord.append(currentCharacter); // adds character to stringbuilder
                        }

                        /* for everything that isn't a white space, it just skips over the character and goes onto the
                        next character. It will not skip to the next iteration, however, if the next read line would
                         be -1 or false. Instead, it will add that last word and the finish the file reading. */
                        if((!(Character.isWhitespace(currentCharacter))) && (inputText.ready())){
                            continue;
                        }

                        String finalWord = currentWord.toString(); // converts now finished word into a string

                        // skips characters that are not valid
                        if(finalWord.length() == 0){
                            continue;
                        }

                        // if word isn't found in the binary search tree, then add it with a value of 1
                        if(BSTMap.get(finalWord) == null){
                            BSTMap.put(finalWord, 1);
                        }

                        // if word is in the binary search tree, increment value by 1
                        else{
                            BSTMap.put(finalWord, BSTMap.get(finalWord) + 1);
                        }

                        currentWord.setLength(0); // clears stringbuilder to be used again
                    }
                }

                inputText.close(); // closing BufferedReader to save memory

                int size = BSTMap.size(); // gets total nodes in the BST map

                Entry[] allWords = new Entry[size]; // makes array that is exact amount of nodes in BST map

                Iterator<Entry<String, Integer>> iterator = BSTMap.iterator(); // make iterator

                /* goes through entire BST map and puts each item into array */
                for(int i = 0; i < size; i++){
                    if(iterator.hasNext()){
                        allWords[i] = iterator.next(); // adds next node to array
                    }
                }

                mergesort(allWords); // sorts in numerical and alphabetic order

                if(limit > size){
                    limit = size; // prints out all items if limit is greater than size of BST Map
                }

                /* iterates through the array to find the highest place that the limit number is
                * so that it can right justify the numbers by the correct space. indexes represent
                * the highest place (ex. 10 = 2 places hence index 2, 100 = 3 places hence index 3, etc.) */
                int[] rightAligned = {0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};
                int numberAligning = Integer.MIN_VALUE; // sets the number to a value that will change
                for(int i = 1; i < rightAligned.length; i++){
                    if((String.valueOf(limit).length()) == (String.valueOf(rightAligned[i]).length())){
                        numberAligning = i; // once the places match, numberAligning is set to i and it breaks
                        break;
                    }
                }

                /* iterates through the array from the first item (largest item) all the way to the limit
                * and finds the longest word for which it saves the length of that word */
                int longestWord = Integer.MIN_VALUE; // sets to lowest number so first iteration changes longestWord
                for(int i = 0; i < limit; i++){
                    int wordLength = ((String)allWords[i].key).length();
                    if(longestWord < wordLength){
                        longestWord = wordLength; // if longest word can be updated by a larger number, it will
                    }
                }

                /* ------- PRINTING ANSWERS BEGINS HERE ------- */

                System.out.println("Total unique words: " + size);

                for(int i = 0; i < limit; i++){
                    int difference = ((String)allWords[i].key).length();
                    int space = (longestWord - difference) + 1; // calculating distance between
                    /* prints out each iteration of i and the results */
                    System.out.printf("%" + numberAligning + "d. %1s%" + space + "s%-1s", i + 1,
                            allWords[i].key.toString(), "", allWords[i].value.toString());
                    if(i < limit - 1){
                        System.out.print(System.lineSeparator());
                    }
                }

                /* ------- PRINTING ANSWERS ENDS HERE ------- */
            }

            catch(FileNotFoundException a){
                System.err.println("Error: Cannot open file '" + args[0] + "' for input.");
                System.exit(1); // not necessary and probably won't run but here for precautionary measures
            }
            catch(IOException b){
                System.err.println("Error: An I/O error occurred reading '" + args[0] + "'.");
                System.exit(1); // if general error occurs while parsing file this will be thrown
            }
        }

        /* avl method */
        else if(args[1].equals("avl")){
            MyMap<String, Integer> AVLTreeMap = new AVLTreeMap<>();

            /* the try block reads every item in the text file character by character, turns then
            into words, and adds them to the avl tree */
            try{
                BufferedReader inputText = new BufferedReader(new FileReader(args[0]));
                int currentInteger; // is the currentCharacter but in integer form to work with BufferedReader
                StringBuilder currentWord = new StringBuilder(); // will contain the words being scanned

                /* current integer will continue as long as there is something in the file being scanned */
                while((currentInteger = inputText.read()) != -1){
                    char currentCharacter = (char) currentInteger; // cast currentInteger as a character

                    /* only goes into statement if there is something to scan next and the character is a letter, dash
                    in the middle of a word, or hyphen */
                    if((!(Character.isWhitespace(currentCharacter))) && ((Character.isLetter(currentCharacter)) ||
                            ((currentCharacter == '-') && (currentWord.length() != 0)) || (currentCharacter == '\''))){
                        currentCharacter = Character.toLowerCase(currentCharacter); // lowercases current character
                        currentWord.append(currentCharacter); // adds character to stringbuilder
                    }

                    /* goes into else statement if character is not a letter, dash in middle or end of word, an
                    apostrophe, or is at end of file */
                    else{
                        /* appends last character to end of word if it is valid */
                        if((!(Character.isWhitespace(currentCharacter))) && ((Character.isLetter(currentCharacter)) ||
                                ((currentCharacter == '-') && (currentWord.length() != 0)) || (currentCharacter == '\''))){
                            currentCharacter = Character.toLowerCase(currentCharacter); // lowercases current character
                            currentWord.append(currentCharacter); // adds character to stringbuilder
                        }

                        /* for everything that isn't a white space, it just skips over the character and goes onto the
                        next character. It will not skip to the next iteration, however, if the next read line would
                         be -1 or false. Instead, it will add that last word and the finish the file reading. */
                        if((!(Character.isWhitespace(currentCharacter))) && (inputText.ready())){
                            continue;
                        }

                        String finalWord = currentWord.toString(); // converts now finished word into a string

                        // skips characters that are not valid
                        if(finalWord.length() == 0){
                            continue;
                        }

                        // if word isn't found in the avl tree, then add it with a value of 1
                        if(AVLTreeMap.get(finalWord) == null){
                            AVLTreeMap.put(finalWord, 1);
                        }

                        // if word is in the avl tree, increment value by 1
                        else{
                            AVLTreeMap.put(finalWord, AVLTreeMap.get(finalWord) + 1);
                        }

                        currentWord.setLength(0); // clears stringbuilder to be used again
                    }
                }

                inputText.close(); // closing BufferedReader to save memory

                int size = AVLTreeMap.size(); // gets total nodes in the AVLTree map

                Entry[] allWords = new Entry[size]; // makes array that is exact amount of nodes in AVLTree map

                Iterator<Entry<String, Integer>> iterator = AVLTreeMap.iterator(); // make iterator

                /* goes through entire AVLTree map and puts each item into array */
                for(int i = 0; i < size; i++){
                    if(iterator.hasNext()){
                        allWords[i] = iterator.next(); // adds next node to array
                    }
                }

                mergesort(allWords); // sorts in numerical and alphabetic order

                if(limit > size){
                    limit = size; // prints out all items if limit is greater than size of AVLTree Map
                }

                /* iterates through the array to find the highest place that the limit number is
                 * so that it can right justify the numbers by the correct space. indexes represent
                 * the highest place (ex. 10 = 2 places hence index 2, 100 = 3 places hence index 3, etc.) */
                int[] rightAligned = {0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};
                int numberAligning = Integer.MIN_VALUE; // sets the number to a value that will change
                for(int i = 1; i < rightAligned.length; i++){
                    if((String.valueOf(limit).length()) == (String.valueOf(rightAligned[i]).length())){
                        numberAligning = i; // once the places match, numberAligning is set to i and it breaks
                        break;
                    }
                }

                /* iterates through the array from the first item (largest item) all the way to the limit
                 * and finds the longest word for which it saves the length of that word */
                int longestWord = Integer.MIN_VALUE; // sets to lowest number so first iteration changes longestWord
                for(int i = 0; i < limit; i++){
                    int wordLength = ((String)allWords[i].key).length();
                    if(longestWord < wordLength){
                        longestWord = wordLength; // if longest word can be updated by a larger number, it will
                    }
                }

                /* ------- PRINTING ANSWERS BEGINS HERE ------- */

                System.out.println("Total unique words: " + size);

                for(int i = 0; i < limit; i++){
                    int difference = ((String)allWords[i].key).length();
                    int space = (longestWord - difference) + 1; // calculating distance between
                    /* prints out each iteration of i and the results */
                    System.out.printf("%" + numberAligning + "d. %1s%" + space + "s%-1s", i + 1,
                            allWords[i].key.toString(), "", allWords[i].value.toString());
                    if(i < limit - 1){
                        System.out.print(System.lineSeparator());
                    }
                }

                /* ------- PRINTING ANSWERS ENDS HERE ------- */
            }

            catch(FileNotFoundException a){
                System.err.println("Error: Cannot open file '" + args[0] + "' for input.");
                System.exit(1); // not necessary and probably won't run but here for precautionary measures
            }
            catch(IOException b){
                System.err.println("Error: An I/O error occurred reading '" + args[0] + "'.");
                System.exit(1); // if general error occurs while parsing file this will be thrown
            }
        }

        /* hash method */
        else if(args[1].equals("hash")){
            MyMap<String, Integer> HashMap = new MyHashMap<>();

            /* the try block reads every item in the text file character by character, turns then
            into words, and adds them to the hash map */
            try{
                BufferedReader inputText = new BufferedReader(new FileReader(args[0]));
                int currentInteger; // is the currentCharacter but in integer form to work with BufferedReader
                StringBuilder currentWord = new StringBuilder(); // will contain the words being scanned

                /* current integer will continue as long as there is something in the file being scanned */
                while((currentInteger = inputText.read()) != -1){
                    char currentCharacter = (char) currentInteger; // cast currentInteger as a character

                    /* only goes into statement if there is something to scan next and the character is a letter, dash
                    in the middle of a word, or hyphen */
                    if((!(Character.isWhitespace(currentCharacter))) && ((Character.isLetter(currentCharacter)) ||
                            ((currentCharacter == '-') && (currentWord.length() != 0)) || (currentCharacter == '\''))){
                        currentCharacter = Character.toLowerCase(currentCharacter); // lowercases current character
                        currentWord.append(currentCharacter); // adds character to stringbuilder
                    }

                    /* goes into else statement if character is not a letter, dash in middle or end of word, an
                    apostrophe, or is at end of file */
                    else{
                        /* appends last character to end of word if it is valid */
                        if((!(Character.isWhitespace(currentCharacter))) && ((Character.isLetter(currentCharacter)) ||
                                ((currentCharacter == '-') && (currentWord.length() != 0)) || (currentCharacter == '\''))){
                            currentCharacter = Character.toLowerCase(currentCharacter); // lowercases current character
                            currentWord.append(currentCharacter); // adds character to stringbuilder
                        }

                        /* for everything that isn't a white space, it just skips over the character and goes onto the
                        next character. It will not skip to the next iteration, however, if the next read line would
                         be -1 or false. Instead, it will add that last word and the finish the file reading. */
                        if((!(Character.isWhitespace(currentCharacter))) && (inputText.ready())){
                            continue;
                        }

                        String finalWord = currentWord.toString(); // converts now finished word into a string

                        // skips characters that are not valid
                        if(finalWord.length() == 0){
                            continue;
                        }

                        // if word isn't found in the hash map, then add it with a value of 1
                        if(HashMap.get(finalWord) == null){
                            HashMap.put(finalWord, 1);
                        }

                        // if word is in the hash map, increment value by 1
                        else{
                            HashMap.put(finalWord, HashMap.get(finalWord) + 1);
                        }

                        currentWord.setLength(0); // clears stringbuilder to be used again
                    }
                }

                inputText.close(); // closing BufferedReader to save memory

                int size = HashMap.size(); // gets total nodes in the hash map

                Entry[] allWords = new Entry[size]; // makes array that is exact amount of nodes in hash map

                Iterator<Entry<String, Integer>> iterator = HashMap.iterator(); // make iterator

                /* goes through entire hash map and puts each item into array */
                for(int i = 0; i < size; i++){
                    if(iterator.hasNext()){
                        allWords[i] = iterator.next(); // adds next node to array
                    }
                }

                mergesort(allWords); // sorts in numerical and alphabetic order

                if(limit > size){
                    limit = size; // prints out all items if limit is greater than size of hash map
                }

                /* iterates through the array to find the highest place that the limit number is
                 * so that it can right justify the numbers by the correct space. indexes represent
                 * the highest place (ex. 10 = 2 places hence index 2, 100 = 3 places hence index 3, etc.) */
                int[] rightAligned = {0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};
                int numberAligning = Integer.MIN_VALUE; // sets the number to a value that will change
                for(int i = 1; i < rightAligned.length; i++){
                    if((String.valueOf(limit).length()) == (String.valueOf(rightAligned[i]).length())){
                        numberAligning = i; // once the places match, numberAligning is set to i and it breaks
                        break;
                    }
                }

                /* iterates through the array from the first item (largest item) all the way to the limit
                 * and finds the longest word for which it saves the length of that word */
                int longestWord = Integer.MIN_VALUE; // sets to lowest number so first iteration changes longestWord
                for(int i = 0; i < limit; i++){
                    int wordLength = ((String)allWords[i].key).length();
                    if(longestWord < wordLength){
                        longestWord = wordLength; // if longest word can be updated by a larger number, it will
                    }
                }

                /* ------- PRINTING ANSWERS BEGINS HERE ------- */

                System.out.println("Total unique words: " + size);

                for(int i = 0; i < limit; i++){
                    int difference = ((String)allWords[i].key).length();
                    int space = (longestWord - difference) + 1; // calculating distance between
                    /* prints out each iteration of i and the results */
                    System.out.printf("%" + numberAligning + "d. %1s%" + space + "s%-1s", i + 1,
                            allWords[i].key.toString(), "", allWords[i].value.toString());
                    if(i < limit - 1){
                        System.out.print(System.lineSeparator());
                    }
                }

                /* ------- PRINTING ANSWERS ENDS HERE ------- */
            }

            catch(FileNotFoundException a){
                System.err.println("Error: Cannot open file '" + args[0] + "' for input.");
                System.exit(1); // not necessary and probably won't run but here for precautionary measures
            }
            catch(IOException b){
                System.err.println("Error: An I/O error occurred reading '" + args[0] + "'.");
                System.exit(1); // if general error occurs while parsing file this will be thrown
            }
        }
    }
}
