README.txt
Name: Joshua Agubata
UNI: jaa2270
Assignment: Final Project

________________________________________________________________________________________________________________________

1. What data structure do you expect to have the best (fastest) performance?
I expected the hash table to have the best performance because to search and insert from the tree
takes Theta(1) time on average (compared to Binary Search trees and AVL trees that take an average of
Theta(lg n) time on average for searches and insertions). Even though AVL trees are quicker than binary
search trees and hash tables (O(lg n) time at the worst case for AVL trees compared to O(n) time at the
worst case for hash tables and binary search trees), I felt like not only would the time that was saved
in searching and inserting for hash maps make up for this worst possible run time but also the fact that
we are rehashing as needed (and decreasing the likelihood that many entries will remain concentrated in
one or a few specific indexes that would take a long time to search).


2. Which one do you expect to be the slowest?
I expected the binary search tree to run the slowest. Compared to the other two data structures, binary
search tree has no perceivable time advantages. It remains on par with AVL tree best-case time complexities
for insertion search which is far above the time it takes for hash maps to do the same action and remains
on par with hash map's time complexities for searching and inserting in the worst-case complexities which
is far above the time it takes for AVL trees to do the same action.

Not speaking about run times, however, I just felt that there was nothing that binary search trees could
do (past the property that all nodes to the left of a node are smaller and to the right are bigger) that
would adjust with the data and optimize its run time. AVLs are able to rotate to keep a very tight average
and worst case search time and a hash table can rehash to experience less collisions but the binary search
can't do much to respond to the data coming in. That is also why I thought it would be the slowest.


3. Do the results of timing your program’s execution match your expectations? If so, briefly explain the correlation.
If not, what run times deviated and briefly explain why you think this is the case.

RESULTS:
BST: 2.25 - 2.30 seconds range, average around 2.26 seconds.
AVL: 2.40 - 2.50 seconds range, average around 2.49 seconds.
Hash: 1.80 - 2.00 seconds range, averaging around 1.9 seconds.

No, this did not match my expectations. I thought that since AVL has the ability to correct itself to have
Theta(lg n) at its best and O(lg n) at its worst it would run quicker than binary search tree but it did not.
I think the descrepancy for BST and AVL may come down to the randomness of the words given. The worst case
of all the values in the binary search tree being on one side of the tree probably didn't occur because there
were not only a lot of words to choose from but the frequency of those words were also varied and random. This
is at the benefit of BST, as it doesn't do any work to balance in the first place and may have a more balanced
tree by chance whereas AVL does do work to balance and therefore will have that extra time necessary to balance
the tree factor into the run time.

However, my thoughts about hash map running quicker than both of them was correct. Like I said before, I
think this is still because the average insertion and search times are leagues ahead of binary search tree
and AVL and the worst insertion and search times are mitigated to some extent by the fact that rehashing
decreases the likelihood of collisions, allowing for each index to be searched faster in theory.

________________________________________________________________________________________________________________________